import React from "react";
import "./Navbar.css";
import PageLinks from "../PageLinks";

function Navbar({ setPage }) {
  return (
    <div className="navbar">
      <div className="title">
        <h3>SARC</h3>
      </div>
      <div className="pages">
        <ul>
          <li
            onClick={() => {
              setPage(1);
            }}>
            <PageLinks text={"About"} />
          </li>
          <li
            onClick={() => {
              setPage(2);
            }}>
            <PageLinks text={"Contact"} />
          </li>
        </ul>
      </div>
    </div>
  );
}

export default Navbar;
