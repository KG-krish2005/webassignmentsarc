import React from "react";
import "./Page1.css";

function Page1() {
  return (
    <div className="main1">
      <h1>About</h1>
      <div className="text">
      The Student Alumni Relations Cell (SARC) is managed by the students of IIT Bombay. 
      SARC is one of the key components of the office of Dean ACR and has launched numerous initiatives which allow for a seamless interaction and networking between students and alumni.
      </div>
    </div>
  );
}

export default Page1;
