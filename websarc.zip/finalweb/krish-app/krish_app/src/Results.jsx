import React from "react";

function Results({ data }) {
  if (data != {} && data != undefined) {
    return (
      <div className="cards">
        <div className="info">
          <span>
            <b>{data.name}</b>
          </span>
          <span>{data.roll}</span>
          <span>ID: {data.id}</span>
        </div>
        <div className="contact">
          <span>Phone No.: {data.phone}</span>
          <span> Email: {data.email}</span>
        </div>
      </div>
    );
  } else return <></>;
}

export default Results;
