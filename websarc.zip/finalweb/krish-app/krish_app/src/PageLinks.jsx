import React from "react";

function PageLinks({ text }) {
  return <>{text}</>;
}

export default PageLinks;
