import React, { useState } from "react";
import "./Contact.css";
import axios from "axios";
import Results from "./Results";

function Contact() {
  let [value, setValue] = useState("");
  let [data, setData] = useState([]);
  const handleInput = (event) => {
    setValue(event.target.value);
  };
  const onSubmit = (event) => {
    event.preventDefault();
    axios
      .get(
        `http://127.0.0.1:3000/myapp/search/?name=${value}&id=${value}&roll=${value}`
      )
      .then((res) => {
        setData(res.data);
      })
      .catch((err) => {
        console.log(err);
      });
  };
  return (
    <div className="mainContact">
      <h1>Contact Us</h1>
      <form onSubmit={onSubmit}>
        <div className="form">
          <label className="form-label" htmlFor="search">
            Search by Name, ID or Roll
          </label>
          <input
            type="text"
            className="form-control"
            placeholder="Search..."
            id="search"
            name="search"
            value={value}
            onChange={handleInput}
          />
          <button className="btn btn-outline-success" type="submit">
            Go
          </button>
        </div>
      </form>
      <div className="results">
        <h3>Results</h3>
        <div className="cardCollection">
          {data.map((el, index) => (
            <Results data={el} key={index} />
          ))}
        </div>
      </div>
    </div>
  );
}

export default Contact;
