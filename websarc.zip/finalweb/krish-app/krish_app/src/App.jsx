import { useState } from "react";
import "./App.css";
import Navbar from "./Navbar/Navbar";
import Page1 from "./Page1";
import Contact from "./Contact";

function App() {
  let [page, setPage] = useState(1);
  return (
    <div className="main">
      <Navbar setPage={setPage} />
      {page == 1 ? <Page1 /> : null}
      {page == 2 ? <Contact /> : null}
    </div>
  );
}

export default App;
