from django.http import JsonResponse
from django.views.decorators.http import require_GET
from .data import data

@require_GET
def search(request):
    roll = request.GET.get('roll')
    person_id = request.GET.get('id')
    name = request.GET.get('name')

    # Filter the data based on the query parameters
    results = []
    for person in data:
        if (roll and person[2] == roll) or (person_id and person[1] == person_id) or (name and person[0].lower() == name.lower()):
            results.append({"name": person[0], "id": person[1], "roll": person[2], "phone": person[3], "email": person[4]})

    return JsonResponse(results, safe=False)