data = [
    ["John Doe", "001", "manager", "+91 222222222", "2@g.com"],
    ["Jane Smith", "002", "manager","+91 222222222", "2@g.com"],
    ["Alice Johnson", "003", "executive","+91 222222222", "2@g.com"],
    # Add more entries as needed
    #[name, id, roll]
]